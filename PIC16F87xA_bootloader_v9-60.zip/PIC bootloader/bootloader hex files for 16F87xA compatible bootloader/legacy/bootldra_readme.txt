
Info on Crystal-Frequency and Baudrate:

The Bootloaderfile for 16MHz/38400bps can also be used 
for 8MHz/19200bps or 4MHz/9600bps

The Bootloaderfile for 20MHz/38400bps can also be used 
for 10MHz/19200bps